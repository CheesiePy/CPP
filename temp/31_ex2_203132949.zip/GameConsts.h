#ifndef HEXGAME_GAMECONSTS_H
#define HEXGAME_GAMECONSTS_H


enum {
    Gray,Blue,Red
};
enum {
    Top = 1,
    Bottom = 2,
    Left = 3,
    Right = 4
};




#endif //HEXGAME_GAMECONSTS_H
