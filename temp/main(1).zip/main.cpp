#include <iostream>
#include "SquareMat.h"
int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
