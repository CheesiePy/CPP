////
//// Created by eb300 on 11/16/2022.
////
//#ifndef HW1_VECTOR_H
//#define HW1_VECTOR_H
//#include <string>
//using namespace std;
//
//class Vector {
//
//public:
//    Vector();  // default c'tor
//    Vector(int dimension);  // standard c'tor
//    Vector(const Vector &v); // copy c'tor
//    Vector &operator=(const Vector &vector); // copy assigment operator
//
//    void set_ob_name(string ob_name);  // set observation name
//    string get_ob_name();
//    void set_dim(int dim); // set observation dimension
//    int get_dim();
//    void set_ob_content(double content[]);
//    float ** get_vector(string ob_name);
//    ~Vector();
//
//
//private:
//    int dim;
//    float ** vector;  // don't use malloc here, if you need to change the vector size use copy c'tor
//    char * observation_name;
//};
//
//#endif //HW1_VECTOR_H
