////
//// Created by eb300 on 11/16/2022.
////
//
//#ifndef HW1_CALCULATOR_H
//#define HW1_CALCULATOR_H
//#include <iostream>
//#include "Vector.h"
//
//using namespace  std;
//
//class Calculator {
//
//public:
//
//    Calculator();
//    void calc_menu();
//    void user_choice(int choice);
//    void new_observation();
//    void print_observation();
//    Vector get_expected_value();
//    Vector get_cov_matrix();
//    Vector parsing_2_v(string content);
//    bool is_empty();
//    ~Calculator();
//
//
//private:
//    Vector * expected_value;
//    Vector * cov_matrix;
//
//};
//
//
//#endif //HW1_CALCULATOR_H
////cout << "[1] New observation" << endl;
////cout << "[2] Print observation" << endl;
////cout << "[3] Expected value vector" << endl;
////cout << "[4] Covariance matrix" << endl;
////cout << "[5] Exit" << endl;