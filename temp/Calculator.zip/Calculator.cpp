////
//// Created by eb300 on 11/16/2022.
////
//#include "Calculator.h"
//#include <stdio.h>
//
//
//// Methods
//void calc_menu() {
//
//    cout << "[1] New observation"
//            "[2] Print observation"
//            "[3] Expected value vector"
//            "[4] Covariance matrix"
//            "[5] Exit" << endl ;
//}
//
//
//void new_observation(){};
//
//void print_observation();
//
//void get_cov_matrix();
//
//void get_expected_value();
////
////void user_choice(int choice) {
////
////    if( (choice < 1)  || (choice > 5) ) {
////        cerr << "Invalid option." << endl;
////    }
////
////    switch (choice) {
////
////        case 1:
////           new_observation();
////           break;
////
////        case 2:
////            print_observation();
////            break;
////
////        case 3:
////            get_expected_value();
////            break;
////
////        case 4:
////            get_cov_matrix();
////            break;
////
////        case 5:
////            abort();
////
////        default :
////            break;
////    }
////}
//
//
//
//
//
//
//
