//
// Created by eb300 on 11/16/2022.
//
//
//#include "Vector.h"
//using namespace std;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ C'tor ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

//Vector() : size(3), vector(new int[size]) {} // Default c'tor
//
//Vector(const int user_size) : size(user_size) {
//    vector = new int[size];
//}
//Vector(Vector v, int new_size = check_size(v)) : size(check_size(v))


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

// Helper functions

//int check_size(Vector v) {
//    return sizeof(&v.vector) / sizeof(v.vector[0]);
//}