
#include <iostream>
#include <string>
#include "Calculator.h"
# include "Vector.h"
using namespace std;
#define MAX_NAME_SIZE 16

void menu() {
    cout << "[1] New observation\n"
            "[2] Print observation\n"
            "[3] Expected value vector\n"
            "[4] Covariance matrix\n"
            "[5] Exit\n" << endl ;
}

void u_choice(int choice, bool calc) {
    // Preconditions: choice is a valid if it is in the range of 1-5
    if( (choice < 1)  || (choice > 5) ) { cerr << "Invalid option." << endl; }

    switch (choice) {
        case 1:
            cout << "new ob" << endl;
            //new_observation();
            break;

        case 2:
            cout << "print ob" << endl;
            //print_observation();
            break;

        case 3:
            cout << "expected calculation" << endl;
            //expected_value(get_expected_value());
            break;

        case 4:
            cout << "covariance calculation" << endl;
            //cov_matrix(get_cov_matrix());
            break;

        case 5:
            calc = false;
            abort();

        default :
            break;
    }
}


void get_new_ob(string name, string data) {
    // think about it -> initialize the string to MAX_NAME_SIZE here \ at the class \ get it at the arguments' scope

    // get the observation name from the user
    cout << "Enter Observation name: " << endl;
    cin >> name;

    // get the observation data from the user
    cout << "Enter observation values: " << endl;
    cin >> data;

    // use outsider function for parsing the ob values

    //

}
int main() {
    // declare instances  -> Calculator, Vector
    // print the calculator menu
//    menu();
//
//    // receiving user choice
//    int choice;
//    bool calc = true;
//    while(calc ) {
//        cin >> choice;
//        u_choice(choice, calc);
//    }







    // receiving user choose

    //
    return 0;
}
