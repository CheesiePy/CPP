#include <iostream>
#include "String.h"
using namespace std;

int main() {
    String *str1 , *str2, *str3;
    str1 = new String("my name is may");
    return 0;
}
