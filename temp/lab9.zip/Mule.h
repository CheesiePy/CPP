#ifndef LAB09_MULE_H
#define LAB09_MULE_H

class Mule : public Donkey public Hourse{

};

#endif //LAB09_MULE_H
